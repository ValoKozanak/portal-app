// Tento súbor je prázdny, pretože useApi hook bol nahradený priamymi API volaniami
export {};
