const path = require('path');

// Monkey-patch Express Router, aby zalogoval zlé path-y
const express = require('express');
const Router = express.Router;
const methods = ['use','get','post','put','patch','delete','all'];

function isBadPath(p) {
  if (typeof p !== 'string') return false;
  // musí začínať na "/", inak je to podozrivé (napr. "http://...", ":" ...)
  if (!p.startsWith('/')) return true;
  // dvojbodka bez parametra (napr. ":/", ": ", ":.")
  if (/:([^a-zA-Z0-9_]|$)/.test(p)) return true;
  return false;
}

methods.forEach(m => {
  const orig = Router[m];
  Router[m] = function(...args) {
    const candidate = args[0];
    if (isBadPath(candidate)) {
      const stack = new Error().stack.split('\n').slice(2,7).join('\n');
      console.error(`💥 Detected bad route path in Router.${m}("${candidate}")\nFrom:\n${stack}\n`);
    }
    return orig.apply(this, args);
  };
});

// Teraz require-ni všetko ako v server.js (ale bez vytvárania vlastného app)
const pairs = [
  ['/api/messages','./routes/messages'],
  ['/api/auth','./routes/auth'],
  ['/api/companies','./routes/companies'],
  ['/api/tasks','./routes/tasks'],
  ['/api/files','./routes/files'],
  ['/api/documents','./routes/documents'],
  ['/api/cms','./routes/cms'],
  ['/api/dropbox','./routes/dropbox'],
  ['/api/hr','./routes/hr'],
  ['/api/payroll','./routes/payroll'],
  ['/api/accounting','./routes/accounting'],
];

const app = express();
pairs.forEach(([mount, mod]) => {
  try {
    const r = require(mod);
    app.use(mount, r);
    console.log('✅ Mounted', mount, 'from', mod);
  } catch (e) {
    console.error('❌ Failed to mount', mount, 'from', mod, '→', e.message);
  }
});
