const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'routes');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.js'));

for (const f of files) {
  const full = path.join(dir, f);
  try {
    require(full);
    console.log('✅ OK   ', f);
  } catch (e) {
    console.log('❌ FAIL', f);
    console.log('   →', e && e.message ? e.message : e);
  }
}
