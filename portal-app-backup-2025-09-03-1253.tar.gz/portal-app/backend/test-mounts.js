const express = require('express');
const app = express();
const pairs = [
  ['/api/messages','./routes/messages'],
  ['/api/auth','./routes/auth'],
  ['/api/companies','./routes/companies'],
  ['/api/tasks','./routes/tasks'],
  ['/api/files','./routes/files'],
  ['/api/documents','./routes/documents'],
  ['/api/cms','./routes/cms'],
  ['/api/dropbox','./routes/dropbox'],
  ['/api/hr','./routes/hr'],
  ['/api/payroll','./routes/payroll'],
  ['/api/accounting','./routes/accounting'],
];
for (const [p,m] of pairs) {
  try {
    const r = require(m);
    app.use(p, r);
    console.log('✅ OK', p, m);
  } catch (e) {
    console.error('💥 FAIL', p, m, '→', e.message);
  }
}
