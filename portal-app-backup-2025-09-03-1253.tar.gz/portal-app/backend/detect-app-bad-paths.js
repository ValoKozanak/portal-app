const express = require('express');

// --- monkey-patch app metódy, aby sme videli zlé pathy ---
const methods = ['use','get','post','put','patch','delete','all'];
const isBad = p => typeof p === 'string' && (
  !p.startsWith('/') ||         // nezačína lomítkom
  /:([^a-zA-Z0-9_]|$)/.test(p)  // dvojbodka bez názvu parametra
);

// patchni prototyp application (nie Router)
methods.forEach(m => {
  const orig = express.application[m];
  express.application[m] = function(...args) {
    const p = args[0];
    if (isBad(p)) {
      const stack = new Error().stack.split('\n').slice(2,7).join('\n');
      console.error(`💥 BAD app.${m}("${p}")\nFrom:\n${stack}\n`);
    }
    return orig.apply(this, args);
  };
});

// zneškodni app.listen, nech nám server naozaj nenaštartuje:
const origListen = express.application.listen;
express.application.listen = function(...args) {
  console.log('⏸ listen() suppressed for inspection:', args);
  return { close(){} };
};

// teraz require server.js – ak niečo registruje zlý path, uvidíme to
try {
  require('./server.js');
  console.log('✅ server.js require() OK (bez štartu)');
} catch (e) {
  console.error('❌ server.js require() failed:', e.message);
}
